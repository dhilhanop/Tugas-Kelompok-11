<?php 
echo $headernya;
echo $contentnya;
echo $footernya;
?>